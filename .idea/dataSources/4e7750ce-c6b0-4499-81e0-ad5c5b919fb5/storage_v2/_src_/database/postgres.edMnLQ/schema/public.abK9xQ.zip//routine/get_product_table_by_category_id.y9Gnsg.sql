create function get_product_table_by_category_id(p_category_id integer)
    returns TABLE(product_id integer, product_name character varying, price numeric, description character varying, images json, params json, colors json, discount_percent numeric, from_delivery integer, to_delivery integer, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying, active boolean)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            pt.product_id,
            pt.product_name::varchar,
            pt.price,
            pt.description::varchar,
            pt.images,
            pt.params,
            pt.colors,
            pt.discount_percent,
            pt.from_delivery,
            pt.to_delivery,
            pt.created_date,
            pt.updated_date,
            pt.created_by::varchar,
            pt.updated_by::varchar,
            pt.active
        FROM product pt
                 JOIN category_product cp ON pt.product_id = cp.product_id
        WHERE cp.category_id = p_category_id;
END;
$$;

alter function get_product_table_by_category_id(integer) owner to postgres;

