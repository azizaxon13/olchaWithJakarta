create function update_promo_code(u_promo_code_id integer, u_value character varying DEFAULT NULL::character varying, u_discount_percent numeric DEFAULT NULL::numeric, u_type character varying DEFAULT NULL::character varying, u_start_date timestamp without time zone DEFAULT NULL::timestamp without time zone, u_days integer DEFAULT NULL::integer, u_fixed_amount numeric DEFAULT NULL::numeric, u_min_amount numeric DEFAULT NULL::numeric, u_updated_by character varying DEFAULT NULL::character varying)
    returns TABLE(promo_code_id integer, value character varying, type character varying, updated_date timestamp without time zone)
    language plpgsql
as
$$
declare
    v_variable text := '';
begin
    if u_value is not null then
        v_variable := v_variable || 'value = ''' || u_value || ''', ';
    end if;

    if u_discount_percent is not null then
        v_variable := v_variable || 'discount_percent = ' || u_discount_percent || ', ';
    end if;

    if u_type is not null then
        v_variable := v_variable || 'type = ''' || u_type || ''', ';
    end if;

    if u_start_date is not null then
        v_variable := v_variable || 'start_date = ''' || u_start_date || ''', ';
    end if;

    if u_days is not null then
        v_variable := v_variable || 'days = ' || u_days || ', ';
    end if;

    if u_fixed_amount is not null then
        v_variable := v_variable || 'fixed_amount = ' || u_fixed_amount || ', ';
    end if;

    if u_min_amount is not null then
        v_variable := v_variable || 'min_amount = ' || u_min_amount || ', ';
    end if;

    if u_updated_by is not null then
        v_variable := v_variable || 'updated_by = ''' || u_updated_by || ''', ';
    end if;

    if length(v_variable) > 0 then
        v_variable := rtrim(v_variable, ', ');
        execute 'update promo_code set ' || v_variable || ', updated_date = current_timestamp where promo_code_id = ' || u_promo_code_id;
    end if;

    return query
        select p.promo_code_id, p.value, p.type, p.updated_date
        from promo_code p
        where p.promo_code_id = u_promo_code_id;
end;
$$;

alter function update_promo_code(integer, varchar, numeric, varchar, timestamp, integer, numeric, numeric, varchar) owner to postgres;

