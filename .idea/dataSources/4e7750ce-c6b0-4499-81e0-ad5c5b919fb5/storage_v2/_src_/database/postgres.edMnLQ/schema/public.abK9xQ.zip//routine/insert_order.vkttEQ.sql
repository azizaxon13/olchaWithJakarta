create function insert_order(i_user_id integer, i_promo_code_id integer, i_total_price numeric, i_status character varying, i_created_by text)
    returns TABLE(user_id integer, promo_code_id integer, total_price numeric, status character varying, created_date timestamp without time zone)
    language plpgsql
as
$$
begin
    return query
        insert into orders (user_id, promo_code_id, total_price, status, created_by)
            values (i_user_id, i_promo_code_id, i_total_price, i_status, i_created_by)
            returning orders.user_id, orders.promo_code_id, orders.total_price, orders.status, orders.created_date;
end;
$$;

alter function insert_order(integer, integer, numeric, varchar, text) owner to postgres;

