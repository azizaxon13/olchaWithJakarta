create function get_products_by_category_id(i_category_id integer) returns jsonb
    language plpgsql
as
$$
begin
    return (
        select json_build_object(
                       'category_id', c.category_id,
                       'category_name', c.category_name,
                       'products', json_agg(
                               json_build_object(
                                       'product_id', p.product_id,
                                       'product_name', p.product_name,
                                       'product_price', p.price,
                                       'product_description', p.description,
                                       'product_images', p.images,
                                       'product_params', p.params,
                                       'product_colors', p.colors,
                                       'product_discount_percent', p.discount_percent,
                                       'product_from_delivery', p.from_delivery,
                                       'product_to_delivery', p.to_delivery,
                                       'product_created_date', p.created_date,
                                       'product_updated_date', p.updated_date,
                                       'product_created_by', p.created_by,
                                       'product_updated_by', p.updated_by,
                                       'product_active', p.active
                               )
                                   )
               )
        from category c
                 inner join public.category_product cp on c.category_id = cp.category_id
                 inner join public.product p on p.product_id = cp.product_id
        where c.category_id = i_category_id
        group by c.category_id, c.category_name
    );
end;
$$;

alter function get_products_by_category_id(integer) owner to postgres;

