create function insert_user(i_name text, i_phone_number text, i_password text, i_email text, i_created_by text)
    returns TABLE(user_id integer, out_name character varying, out_phone_number character varying, out_email character varying, out_created_date timestamp without time zone)
    language plpgsql
as
$$
begin
    return query
        insert into users (name, phone_number, password, email, created_by)
            values (i_name, i_phone_number, i_password, i_email, i_created_by)
            returning users.user_id, users.name, users.phone_number, users.email, users.created_date;
end;
$$;

alter function insert_user(text, text, text, text, text) owner to postgres;

