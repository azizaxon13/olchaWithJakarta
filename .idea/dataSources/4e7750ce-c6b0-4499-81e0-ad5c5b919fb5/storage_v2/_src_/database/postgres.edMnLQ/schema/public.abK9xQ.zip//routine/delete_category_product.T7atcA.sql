create function delete_category_product(p_category_product_id integer)
    returns TABLE(category_product_id integer, category_id integer, product_id integer, active boolean)
    language plpgsql
as
$$
begin
    return query
        update category_product cp
            set active = false
            where cp.category_product_id = p_category_product_id and cp.active = true
            returning cp.category_product_id, cp.category_id, cp.product_id, cp.active;
end;
$$;

alter function delete_category_product(integer) owner to postgres;

