create function get_all_carts()
    returns TABLE(cart_id integer, user_id integer, product_id integer, quantity integer, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying, active boolean)
    language plpgsql
as
$$
begin
    return query
        select cart.cart_id, cart.user_id, cart.product_id, cart.quantity, cart.created_date, cart.updated_date, cart.created_by, cart.updated_by, cart.active
        from cart where cart.active = true;
end;
$$;

alter function get_all_carts() owner to postgres;

