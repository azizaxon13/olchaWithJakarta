create function insert_category_product(i_category_id integer, i_product_id integer, i_created_by character varying)
    returns TABLE(category_product_id integer, category_id integer, product_id integer, created_date timestamp without time zone)
    language plpgsql
as
$$
begin
    return query
        insert into category_product (category_id, product_id, created_by)
            values (i_category_id, i_product_id, i_created_by)
            returning category_product.category_product_id, category_product.category_id, category_product.product_id, category_product.created_date;
end;
$$;

alter function insert_category_product(integer, integer, varchar) owner to postgres;

