create function signin_user1(i_username character varying, i_password character varying)
    returns TABLE(id integer, name character varying, username character varying, email character varying)
    language plpgsql
as
$$
    begin
    return query
        select u.id, u.name, u.username, u.email from users1 u where u.username = i_username and u.password = i_password;
   end;
$$;

alter function signin_user1(varchar, varchar) owner to postgres;

