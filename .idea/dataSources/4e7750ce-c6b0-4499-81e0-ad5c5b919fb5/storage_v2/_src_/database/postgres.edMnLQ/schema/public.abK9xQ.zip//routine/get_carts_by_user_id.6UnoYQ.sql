create function get_carts_by_user_id(p_user_id integer) returns json
    language plpgsql
as
$$
begin
    return (
        select json_build_object(
                       'user_id', u.user_id,
                       'user_name', u.name,
                       'phone_number', u.phone_number,
                       'user_email', u.email,
                       'carts', json_agg(
                               json_build_object(
                                       'cart_id', c.cart_id,
                                       'product_id', c.product_id,
                                       'quantity', c.quantity
                               )
                                )
               )
        from users u
                 join cart c on u.user_id = c.user_id
        where u.user_id = p_user_id
        group by u.user_id, u.name, u.phone_number, u.email
    );
end;
$$;

alter function get_carts_by_user_id(integer) owner to postgres;

