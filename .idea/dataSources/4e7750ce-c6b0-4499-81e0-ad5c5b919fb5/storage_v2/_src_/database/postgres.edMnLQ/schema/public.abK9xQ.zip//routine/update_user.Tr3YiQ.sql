create function update_user(u_user_id integer, u_name text DEFAULT NULL::text, u_phone_number text DEFAULT NULL::text, u_email text DEFAULT NULL::text, u_updated_by text DEFAULT NULL::text)
    returns TABLE(user_id integer, name character varying, phone_number character varying, email character varying, updated_date timestamp without time zone)
    language plpgsql
as
$$
declare
    v_variable text := '';
begin
    if u_name is not null then
        v_variable := v_variable || 'name = ''' || u_name || ''', ';
    end if;

    if u_phone_number is not null then
        v_variable := v_variable || 'phone_number = ''' || u_phone_number || ''', ';
    end if;

    if u_email is not null then
        v_variable := v_variable || 'email = ''' || u_email || ''', ';
    end if;

    if u_updated_by is not null then
        v_variable := v_variable || 'updated_by = ''' || u_updated_by || ''', ';
    end if;

    if length(v_variable) > 0 then
        v_variable := rtrim(v_variable, ', ');
    end if;

    if length(v_variable) > 0 then
        execute 'update users set ' || v_variable || ', updated_date = current_timestamp where user_id = ' || u_user_id;
    end if;

    return query
        select u.user_id, u.name, u.phone_number, u.email, u.updated_date
        from users u
where u.user_id = u_user_id;
end;
$$;

alter function update_user(integer, text, text, text, text) owner to postgres;

