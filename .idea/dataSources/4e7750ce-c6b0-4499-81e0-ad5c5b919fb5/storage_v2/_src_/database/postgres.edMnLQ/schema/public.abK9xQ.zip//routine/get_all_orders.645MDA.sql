create function get_all_orders()
    returns TABLE(order_id integer, user_id integer, promo_code_id integer, total_price numeric, status character varying, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying, active boolean)
    language plpgsql
as
$$
begin
    return query
        select orders.order_id, orders.user_id, orders.promo_code_id, orders.total_price, orders.status, orders.created_date, orders.updated_date, orders.created_by, orders.updated_by, orders.active
        from orders where orders.active = true;
end;
$$;

alter function get_all_orders() owner to postgres;

