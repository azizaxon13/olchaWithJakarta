create procedure validation(IN i_worker_id integer)
    language plpgsql
as
$$
DECLARE
    N record;

BEGIN
    FOR N IN SELECT * FROM laptop loop
        update laptop set status = 'READY' where id=N.id and worker_id = i_worker_id;
    END LOOP;
    if IS_READY(i_worker_id) = false then
        rollback ;

    end if;
     commit;

end;
$$;

alter procedure validation(integer) owner to postgres;

grant execute on procedure validation(integer) to readonlu;

grant execute on procedure validation(integer) to writeonly;

