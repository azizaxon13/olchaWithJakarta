create function register_user1(i_name character varying, i_username character varying, i_password character varying, i_email character varying)
    returns TABLE(id integer, name character varying, username character varying, email character varying)
    language plpgsql
as
$$
begin
    return query
        insert into users1 (name, username, password, email)
            values (i_name, i_username, i_password, i_email)
            returning users1.id, users1.name, users1.username, users1.email;
end;
$$;

alter function register_user1(varchar, varchar, varchar, varchar) owner to postgres;

