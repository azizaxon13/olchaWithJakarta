create function delete_order(p_order_id integer)
    returns TABLE(order_id integer, user_id integer, promo_code_id integer, total_price numeric, status character varying, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying, active boolean)
    language plpgsql
as
$$
declare
    v_row_count integer;
begin
    -- Perform the update and capture how many rows were updated
    update orders o
    set active = false, updated_date = current_timestamp
    where o.order_id = p_order_id and o.active = true
    returning o.order_id, o.user_id, o.promo_code_id, o.total_price, o.status, o.created_date, o.updated_date, o.created_by, o.updated_by, o.active
        into order_id, user_id, promo_code_id, total_price, status, created_date, updated_date, created_by, updated_by, active;

    -- Check if a row was updated
    GET DIAGNOSTICS v_row_count = ROW_COUNT;

    -- If no rows were affected, raise a notice and return nothing
    if v_row_count = 0 then
        raise notice 'No rows updated. Either the order_id does not exist or the order is already inactive.';
        return;
    end if;

    -- Return the result set if the update was successful
    return query
        select order_id, user_id, promo_code_id, total_price, status, created_date, updated_date, created_by, updated_by, active;
end;
$$;

alter function delete_order(integer) owner to postgres;

