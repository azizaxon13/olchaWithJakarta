create function delete_user(p_user_id integer)
    returns TABLE(user_id integer, name character varying, phone_number character varying, email character varying, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying, active boolean)
    language plpgsql
as
$$
begin
    return query
        update users u
            set active = false
            where u.user_id = p_user_id
            returning u.user_id, u.name, u.phone_number, u.email, u.created_date, u.updated_date, u.created_by, u.updated_by, u.active;
end;
$$;

alter function delete_user(integer) owner to postgres;

