create function delete_product(p_product_id integer)
    returns TABLE(product_id integer, product_name character varying, price numeric, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying, active boolean)
    language plpgsql
as
$$
begin
    return query
        update product p
            set active = false
            where p.product_id = p_product_id and p.active = true
            returning p.product_id, p.product_name, p.price, p.created_date, p.updated_date, p.created_by, p.updated_by, p.active;
end;
$$;

alter function delete_product(integer) owner to postgres;

