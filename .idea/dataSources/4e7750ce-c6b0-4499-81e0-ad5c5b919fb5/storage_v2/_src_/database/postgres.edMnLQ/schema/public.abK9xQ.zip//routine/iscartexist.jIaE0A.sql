create function iscartexist(userid integer, productid integer) returns boolean
    language plpgsql
as
$$
declare
    v_count int := 0;
begin
    select count(*)
    into v_count
    from cart c
    where c.user_id = userid
      and c.product_id = productid;

    return v_count = 0;
end;
$$;

alter function iscartexist(integer, integer) owner to postgres;

