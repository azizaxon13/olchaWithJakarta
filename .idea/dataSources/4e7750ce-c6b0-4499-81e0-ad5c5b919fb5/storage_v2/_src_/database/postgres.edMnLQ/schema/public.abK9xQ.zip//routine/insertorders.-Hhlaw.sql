create function insertorders(p_status character varying, i_order_json jsonb) returns void
    language plpgsql
as
$$
    declare
        v_order_id int;
        v_status_order_product varchar := '';
        v_user_id int := (i_order_json ->> 'userid')::int;
        v_product jsonb;
begin
    insert into orders(user_id, promo_code_id, status)
    values (
               (i_order_json ->> 'userid')::int,
               (i_order_json ->> 'promocodeid')::int,
               p_status
           )
    returning order_id into v_order_id;

    for v_product in select * from jsonb_array_elements(i_order_json -> 'products')
        loop
            if isCartExist(v_user_id, (v_product ->> 'productid')::int) then
                v_status_order_product := 'MISSED';
            elseif (isactivecart(v_order_id, (v_product ->> 'productid')::int) = true) then
                v_status_order_product := 'CREATED';
            else
                v_status_order_product := 'PREVIOUSLY_ORDERED';
            end if;

            insert into order_product(order_id, product_id, quantity, status)
            values (
                       v_order_id,
                       (v_product ->> 'productid')::int,
                       (v_product ->> 'quantity')::int,
                       v_status_order_product
                   );
        end loop;
end;
    $$;

alter function insertorders(varchar, jsonb) owner to postgres;

