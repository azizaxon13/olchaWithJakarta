create function get_order(i_order_id integer)
    returns TABLE(order_id integer, product_id integer, quantity integer, status text)
    language plpgsql
as
$$
BEGIN
    -- Retrieve the product details for the given order, including their statuses
    RETURN QUERY
        SELECT
            op.order_id,
            op.product_id,
            op.quantity,
            op.status
        FROM
            order_product op
        WHERE
            op.order_id = i_order_id;
END;
$$;

alter function get_order(integer) owner to postgres;

