create function update_category(u_category_id integer, u_category_name character varying DEFAULT NULL::character varying, u_parent_id integer DEFAULT NULL::integer, u_updated_by text DEFAULT NULL::text)
    returns TABLE(category_id integer, category_name character varying, parent_id integer, updated_date timestamp without time zone)
    language plpgsql
as
$$
declare
    v_variable text := '';
begin
    if u_category_name is not null then
        v_variable := v_variable || 'category_name = ''' || u_category_name || ''', ';
    end if;

    if u_parent_id is not null then
        v_variable := v_variable || 'parent_id = ' || u_parent_id || ', ';
    end if;

    if u_updated_by is not null then
        v_variable := v_variable || 'updated_by = ''' || u_updated_by || ''', ';
    end if;

    if length(v_variable) > 0 then
        v_variable := rtrim(v_variable, ', ');
    end if;

    if length(v_variable) > 0 then
        execute 'update category set ' || v_variable || ', updated_date = current_timestamp where category_id = ' || u_category_id;
    end if;

    return query
        select c.category_id, c.category_name, c.parent_id, c.updated_date
        from category c
        where c.category_id = u_category_id;
end;
$$;

alter function update_category(integer, varchar, integer, text) owner to postgres;

