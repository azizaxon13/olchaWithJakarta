create function insert_product(i_product_name character varying, i_price numeric, i_description text DEFAULT NULL::text, i_images json DEFAULT NULL::json, i_params json DEFAULT NULL::json, i_colors json DEFAULT NULL::json, i_discount_percent numeric DEFAULT NULL::numeric, i_from_delivery integer DEFAULT NULL::integer, i_to_delivery integer DEFAULT NULL::integer, i_created_by character varying DEFAULT NULL::character varying)
    returns TABLE(product_id integer, out_product_name character varying, out_price numeric, out_created_date timestamp without time zone)
    language plpgsql
as
$$
begin
    return query
        insert into product (
                             product_name, price, description, images, params, colors, discount_percent, from_delivery, to_delivery, created_by
            )
            values (
                       i_product_name, i_price, i_description, i_images, i_params, i_colors, i_discount_percent, i_from_delivery, i_to_delivery, i_created_by
                   )
            returning product.product_id, product.product_name, product.price, product.created_date;
end;
$$;

alter function insert_product(varchar, numeric, text, json, json, json, numeric, integer, integer, varchar) owner to postgres;

