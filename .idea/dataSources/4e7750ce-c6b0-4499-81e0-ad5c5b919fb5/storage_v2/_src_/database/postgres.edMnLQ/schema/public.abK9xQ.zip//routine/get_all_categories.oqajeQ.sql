create function get_all_categories()
    returns TABLE(category_id integer, category_name character varying, parent_id integer, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying, active boolean)
    language plpgsql
as
$$
begin
    return query
        select category.category_id, category.category_name, category.parent_id, category.created_date, category.updated_date, category.created_by, category.updated_by, category.active
        from category where category.active = true;
end;
$$;

alter function get_all_categories() owner to postgres;

