create function get_all_promo_codes()
    returns TABLE(promo_code_id integer, value character varying, type character varying, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying, active boolean)
    language plpgsql
as
$$
begin
    return query
        select p.promo_code_id, p.value, p.type, p.created_date, p.updated_date, p.created_by, p.updated_by, p.active
        from promo_code p
        where p.active = true;
end;
$$;

alter function get_all_promo_codes() owner to postgres;

