create function get_all_reviews()
    returns TABLE(review_id integer, product_id integer, user_id integer, rating integer, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying, active boolean)
    language plpgsql
as
$$
begin
    return query
        select r.review_id, r.product_id, r.user_id, r.rating, r.created_date, r.updated_date, r.created_by, r.updated_by, r.active
        from review r
        where r.active = true;
end;
$$;

alter function get_all_reviews() owner to postgres;

