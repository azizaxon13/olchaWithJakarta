create function insert_review(i_product_id integer, i_user_id integer, i_rating integer, i_comment text DEFAULT NULL::text, i_created_by character varying DEFAULT NULL::character varying)
    returns TABLE(review_id integer, product_id integer, user_id integer, rating integer, created_date timestamp without time zone)
    language plpgsql
as
$$
begin
    return query
        insert into review (
                            product_id, user_id, rating, comment, created_by
            )
            values (
                       i_product_id, i_user_id, i_rating, i_comment, i_created_by
                   )
            returning review.review_id, review.product_id, review.user_id, review.rating, review.created_date;
end;
$$;

alter function insert_review(integer, integer, integer, text, varchar) owner to postgres;

