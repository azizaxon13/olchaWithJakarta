create function insert_category(i_category_name character varying DEFAULT NULL::character varying, i_parent_id integer DEFAULT NULL::integer, i_created_by character varying DEFAULT NULL::character varying)
    returns TABLE(category_id integer, category_name character varying, parent_id integer, created_date timestamp without time zone)
    language plpgsql
as
$$
begin
    return query
        insert into category (category_name, parent_id, created_by)
            values (i_category_name, i_parent_id, i_created_by)
            returning category.category_id, category.category_name, category.parent_id, category.created_date;
end;
$$;

alter function insert_category(varchar, integer, varchar) owner to postgres;

