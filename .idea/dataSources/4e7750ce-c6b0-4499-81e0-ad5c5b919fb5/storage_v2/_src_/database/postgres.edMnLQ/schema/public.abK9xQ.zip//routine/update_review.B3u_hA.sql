create function update_review(u_review_id integer, u_rating integer DEFAULT NULL::integer, u_comment text DEFAULT NULL::text, u_updated_by character varying DEFAULT NULL::character varying)
    returns TABLE(review_id integer, product_id integer, user_id integer, rating integer, updated_date timestamp without time zone)
    language plpgsql
as
$$
declare
    v_variable text := '';
begin
    if u_rating is not null then
        v_variable := v_variable || 'rating = ' || u_rating || ', ';
    end if;

    if u_comment is not null then
        v_variable := v_variable || 'comment = ''' || u_comment || ''', ';
    end if;

    if u_updated_by is not null then
        v_variable := v_variable || 'updated_by = ''' || u_updated_by || ''', ';
    end if;

    if length(v_variable) > 0 then
        v_variable := rtrim(v_variable, ', ');
        execute 'update review set ' || v_variable || ', updated_date = current_timestamp where review_id = ' || u_review_id;
    end if;

    return query
        select r.review_id, r.product_id, r.user_id, r.rating, r.updated_date
        from review r
        where r.review_id = u_review_id;
end;
$$;

alter function update_review(integer, integer, text, varchar) owner to postgres;

