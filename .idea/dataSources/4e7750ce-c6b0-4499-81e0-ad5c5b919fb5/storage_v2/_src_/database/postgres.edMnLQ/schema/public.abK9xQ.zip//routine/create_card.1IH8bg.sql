create function create_card(i_owner_id integer, i_card_name character varying, i_card_number character varying, i_pin_code integer, i_balance integer, i_expiry_date integer, i_active boolean)
    returns TABLE(owner_id integer, card_id integer, card_name character varying, card_number character varying, card_balance integer, card_expiry_date integer, active boolean)
    language plpgsql
as
$$
begin
    return query
        insert into cards (owner_id, card_name, card_number, pin_code, balance, expiry_date, active)
            values (i_owner_id, i_card_name, i_card_number, i_pin_code,  i_balance, i_expiry_date, i_active)
            returning cards.owner_id, cards.card_id, cards.card_name, cards.card_number, cards.balance, cards.expiry_date, cards.active;
end ;
$$;

alter function create_card(integer, varchar, varchar, integer, integer, integer, boolean) owner to postgres;

