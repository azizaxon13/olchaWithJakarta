create function get_order_info_json(p_order_id integer) returns jsonb
    language plpgsql
as
$$
declare
    v_order_info jsonb;
begin
    select
        jsonb_build_object(
                'user_id', o.user_id,
                'promo_code_id', o.promo_code_id,
                'products', (
                    select jsonb_agg(
                                   jsonb_build_object(
                                           'product_id', p.product_id,
                                           'product_name', p.product_name,
                                           'price', p.price,
                                           'description', p.description,
                                           'images', p.images,
                                           'params', p.params,
                                           'colors', p.colors,
                                           'discount_percent', p.discount_percent,
                                           'from_delivery', p.from_delivery,
                                           'to_delivery', p.to_delivery,
                                           'quantity', op.quantity
                                   )
                           )
                    from product p
                             join order_product op on p.product_id = op.product_id
                    where op.order_id = p_order_id
                )
        )
    into v_order_info
    from orders o
    where o.order_id = p_order_id;

    return v_order_info;
end;
$$;

alter function get_order_info_json(integer) owner to postgres;

