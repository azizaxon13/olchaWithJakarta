create function is_ready(i_worker_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
    N record;
    is_ready boolean := TRUE;
    CNT INT;
BEGIN
    FOR N IN SELECT * FROM laptop WHERE worker_id = i_worker_id loop
        SELECT COUNT(*) INTO CNT FROM laptop_status ls WHERE name = N.status AND ls.status ilike 'BAD';
        IF CNT > 0 THEN
            is_ready := FALSE;
            EXIT;
        END IF;
    END LOOP;
    RETURN is_ready;
end;
    $$;

alter function is_ready(integer) owner to postgres;

