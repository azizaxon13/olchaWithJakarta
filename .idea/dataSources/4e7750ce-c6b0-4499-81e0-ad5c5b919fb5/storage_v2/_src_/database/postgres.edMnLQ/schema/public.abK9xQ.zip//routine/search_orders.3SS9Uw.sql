create function search_orders(g_order_id integer DEFAULT NULL::integer, g_user_id integer DEFAULT NULL::integer, g_promo_code_id integer DEFAULT NULL::integer, g_total_price numeric DEFAULT NULL::numeric, g_status character varying DEFAULT NULL::character varying, g_created_by character varying DEFAULT NULL::character varying, g_updated_by character varying DEFAULT NULL::character varying, g_active boolean DEFAULT NULL::boolean) returns jsonb
    language plpgsql
as
$$
declare
    v_query text := '';
begin
    -- Dynamically add conditions
    if g_order_id is not null then
        v_query := v_query || ' and o.order_id = ' || g_order_id;
    end if;

    if g_user_id is not null then
        v_query := v_query || ' and o.user_id = ' || g_user_id;
    end if;

    if g_promo_code_id is not null then
        v_query := v_query || ' and o.promo_code_id = ' || g_promo_code_id;
    end if;

    if g_total_price is not null then
        v_query := v_query || ' and o.total_price = ' || g_total_price;
    end if;

    if g_status is not null then
        v_query := v_query || ' and o.status ilike ''%' || g_status || '%''';
    end if;

    if g_created_by is not null then
        v_query := v_query || ' and o.created_by ilike ''%' || g_created_by || '%''';
    end if;

    if g_updated_by is not null then
        v_query := v_query || ' and o.updated_by ilike ''%' || g_updated_by || '%''';
    end if;

    if g_active is not null then
        v_query := v_query || ' and o.active = ' || g_active;
    end if;

    -- Append ordering
    v_query := v_query || ' order by o.order_id desc';

    -- Execute dynamic query and return aggregated JSON array
    return execute 'select jsonb_agg(jsonb_build_object(
        ''order_id'', o.order_id,
        ''user_id'', o.user_id,
        ''promo_code_id'', o.promo_code_id,
        ''total_price'', o.total_price,
        ''status'', o.status,
        ''created_date'', o.created_date,
        ''updated_date'', o.updated_date,
        ''created_by'', o.created_by,
        ''updated_by'', o.updated_by,
        ''active'', o.active,
        ''products'', (
            select jsonb_agg(
                jsonb_build_object(
                    ''product_id'', p.product_id,
                    ''product_name'', p.product_name,
                    ''price'', p.price,
                    ''status'', op.status,
                    ''quantity'', op.quantity,
                    ''created_date'', op.created_date,
                    ''updated_date'', op.updated_date
                )
                order by
                    case op.status
                        when ''missed'' then 1
                        when ''previously_ordered'' then 2
                        when ''created'' then 3
                        else 4
                    end,
                    op.order_product_id desc
            )
            from order_product op
            join product p on p.product_id = op.product_id
            where op.order_id = o.order_id
        )
    )) as orders_json
    from orders o
    where 1=1' || v_query;
end;
$$;

alter function search_orders(integer, integer, integer, numeric, varchar, varchar, varchar, boolean) owner to postgres;

