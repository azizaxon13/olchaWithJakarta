create function create_order(i_order_json jsonb) returns boolean
    language plpgsql
as
$$
declare
    v_order_id  int     := 0;
    v_product   jsonb;
    v_userId    int     := (i_order_json ->> 'userId')::int;
    v_result    int;
begin
    insert into orders(user_id, status, promo_code_id)
    values (v_userId, 'CREATED', (i_order_json ->> 'promoCodeId')::int)
    returning order_id into v_order_id;

    v_result := pre_order_validation(i_order_id := v_order_id, i_order_json := i_order_json);

    if v_result = -1 then
        update orders set status = 'MISSED' where order_id = v_order_id;
        return false;
    elsif v_result = -2 then
        update orders set status = 'PREVIOUSLY_ORDERED' where order_id = v_order_id;
        return false;
    end if;

    for v_product in select jsonb_array_elements(i_order_json -> 'products')
        loop
            perform deactivate_carts((v_product ->> 'productId')::int, v_userId);
        end loop;

    return true;
end;
$$;

alter function create_order(jsonb) owner to postgres;

