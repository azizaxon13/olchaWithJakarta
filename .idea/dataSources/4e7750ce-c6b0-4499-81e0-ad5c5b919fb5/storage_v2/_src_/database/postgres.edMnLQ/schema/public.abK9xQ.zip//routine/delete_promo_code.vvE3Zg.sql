create function delete_promo_code(p_promo_code_id integer)
    returns TABLE(promo_code_id integer, value character varying, type character varying, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying, active boolean)
    language plpgsql
as
$$
begin
    return query
        update promo_code p
            set active = false
            where p.promo_code_id = p_promo_code_id and p.active = true
            returning p.promo_code_id, p.value, p.type, p.created_date, p.updated_date, p.created_by, p.updated_by, p.active;
end;
$$;

alter function delete_promo_code(integer) owner to postgres;

