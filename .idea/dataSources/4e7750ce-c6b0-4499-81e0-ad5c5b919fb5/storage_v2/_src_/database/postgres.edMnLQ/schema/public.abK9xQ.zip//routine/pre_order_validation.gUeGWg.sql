create function pre_order_validation(i_order_id integer, i_order_json jsonb) returns integer
    language plpgsql
as
$$
declare
    v_product jsonb;
    v_userId int := (i_order_json ->> 'userId')::int;
    v_result int := 0;
    v_productId int;
begin
    for v_product in select jsonb_array_elements(i_order_json -> 'products')
        loop
            v_productId := (v_product ->> 'productId')::int;

            if (select 1 from cart where user_id = v_userId and product_id = v_productId) is null then
                insert into order_product(order_id, product_id, quantity, status)
                values (i_order_id, v_productId, (v_product ->> 'quantity')::int, 'MISSED');
                v_result := -1;
            elsif (select 1
                   from cart
                   where user_id = v_userId
                     and product_id = v_productId
                     and active = true) is null then
                insert into order_product(order_id, product_id, quantity, status)
                values (i_order_id, v_productId, (v_product ->> 'quantity')::int, 'PREVIOUSLY_ORDERED');

                if v_result <> -1 then
                    v_result := -2;
                end if;
            else
                insert into order_product(order_id, product_id, quantity, status)
                values (i_order_id, v_productId, (v_product ->> 'quantity')::int, 'SUCCESS');
            end if;
        end loop;

    return v_result;
end;
$$;

alter function pre_order_validation(integer, jsonb) owner to postgres;

