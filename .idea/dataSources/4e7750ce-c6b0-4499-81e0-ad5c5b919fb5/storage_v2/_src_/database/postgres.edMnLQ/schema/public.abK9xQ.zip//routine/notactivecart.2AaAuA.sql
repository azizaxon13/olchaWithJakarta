create function notactivecart(userid integer, productid integer) returns boolean
    language plpgsql
as
$$
declare
    v_count int := 0;
begin
    select count(*)
    into v_count
    from cart c
    where c.user_id = userid
      and c.product_id = productid
      and c.active = true;

    return v_count = 0;
end;
$$;

alter function notactivecart(integer, integer) owner to postgres;

