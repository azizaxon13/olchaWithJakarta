create function search(i_order_id integer DEFAULT NULL::integer, i_username character varying DEFAULT NULL::character varying, i_promo_code_value character varying DEFAULT NULL::character varying, i_product_name character varying DEFAULT NULL::character varying, i_product_price numeric DEFAULT NULL::numeric, i_product_quantity integer DEFAULT NULL::integer, i_order_status text DEFAULT NULL::text, i_order_created timestamp without time zone DEFAULT NULL::timestamp without time zone)
    returns TABLE(order_id integer, order_status character varying, name character varying, user_phone_number character varying, user_email character varying, promo_code_value character varying, promo_code_type character varying, promo_code_days integer, promo_code_fixed integer)
    language plpgsql
as
$$
DECLARE
    v_query text := 'SELECT o.order_id, o.status, u.name, u.phone_number, u.email, ' ||
                    'pc.value, pc.type, pc.days AS promo_code_days, pc.fixed_amount AS promo_code_fixed ' ||
                    'FROM orders o ' ||
                    'INNER JOIN users u ON o.user_id = u.user_id ' ||
                    'INNER JOIN promo_code pc ON o.promo_code_id = pc.promo_code_id ' ||
                    'INNER JOIN order_product op ON o.order_id = op.order_id ' ||
                    'INNER JOIN product p ON op.product_id = p.product_id WHERE TRUE';
BEGIN
    -- Append filters to the query based on input parameters
    IF i_order_id IS NOT NULL THEN
        v_query := v_query || ' AND o.order_id = ' || i_order_id;
    END IF;

    IF i_username IS NOT NULL THEN
        v_query := v_query || ' AND u.name ILIKE ''%' || i_username || '%''';
    END IF;

    IF i_promo_code_value IS NOT NULL THEN
        v_query := v_query || ' AND pc.value ILIKE ''%' || i_promo_code_value || '%''';
    END IF;

    IF i_product_name IS NOT NULL THEN
        v_query := v_query || ' AND p.name ILIKE ''%' || i_product_name || '%''';
    END IF;

    IF i_product_price IS NOT NULL THEN
        v_query := v_query || ' AND p.price = ' || i_product_price;  -- Corrected to use `price` column
    END IF;

    IF i_product_quantity IS NOT NULL THEN
        v_query := v_query || ' AND op.product_quantity = ' || i_product_quantity;  -- Corrected to use `product_quantity` from order_product
    END IF;

    IF i_order_status IS NOT NULL THEN
        v_query := v_query || ' AND o.status ILIKE ''%' || i_order_status || '%''';
    END IF;

    IF i_order_created IS NOT NULL THEN
        v_query := v_query || ' AND o.created_at >= ''' || i_order_created || '''';  -- Make sure to use the correct timestamp column name
    END IF;

    -- Execute the dynamically constructed query
    RETURN QUERY EXECUTE v_query;
END;
$$;

alter function search(integer, varchar, varchar, varchar, numeric, integer, text, timestamp) owner to postgres;

