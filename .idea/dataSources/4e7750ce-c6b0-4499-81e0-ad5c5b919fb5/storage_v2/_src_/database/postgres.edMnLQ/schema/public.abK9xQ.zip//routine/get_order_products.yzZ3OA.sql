create function get_order_products(p_order_id integer)
    returns TABLE(order_created_date timestamp without time zone, order_id integer, order_status character varying, name character varying, phone_number character varying, email character varying, value character varying, promo_code_discount_percent numeric, type character varying, start_date timestamp without time zone, days integer, fixed_amount numeric, min_amount numeric, product_id integer, product_name character varying, price numeric, description text, images json, params json, colors json, product_discount_percent numeric, quantity integer, order_project_status character varying)
    language plpgsql
as
$$
begin
    return query
        select
            o.created_date,
            o.order_id,
            o.status,
            u.name,
            u.phone_number,
            u.email,
            pr.value,
            pr.discount_percent,
            pr.type,
            pr.start_date,
            pr.days,
            pr.fixed_amount,
            pr.min_amount,
            p.product_id,
            p.product_name,
            p.price,
            p.description,
            p.images,
            p.params,
            p.colors,
            p.discount_percent,
            op.quantity,
            op.status
        from
            product p
                join order_product op on p.product_id = op.product_id
                join orders o on o.order_id = op.order_id
                join users u on u.user_id = o.user_id
                join promo_code pr on pr.promo_code_id = o.promo_code_id
        where
            o.order_id = p_order_id order by o.created_date desc;
end;
$$;

alter function get_order_products(integer) owner to postgres;

