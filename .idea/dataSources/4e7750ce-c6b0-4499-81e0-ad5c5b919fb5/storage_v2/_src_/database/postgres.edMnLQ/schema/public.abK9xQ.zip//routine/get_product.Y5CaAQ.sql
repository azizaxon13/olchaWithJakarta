create function get_product(g_product_id integer DEFAULT NULL::integer, g_product_name character varying DEFAULT NULL::character varying, g_price numeric DEFAULT NULL::numeric, g_created_by character varying DEFAULT NULL::character varying, g_updated_by character varying DEFAULT NULL::character varying, g_active boolean DEFAULT NULL::boolean)
    returns TABLE(product_id integer, product_name character varying, price numeric, created_date timestamp without time zone)
    language plpgsql
as
$$
declare
    v_query text := '';
begin
    if g_product_id != 0 then
        v_query := v_query || ' and p.product_id = ' || g_product_id;
    end if;

    if g_product_name is not null then
        v_query := v_query || ' and p.product_name ilike ''' || g_product_name || '''';
    end if;

    if g_price is not null then
        v_query := v_query || ' and p.price = ' || g_price;
    end if;

    if g_created_by is not null then
        v_query := v_query || ' and p.created_by ilike ''' || g_created_by || '''';
    end if;

    if g_updated_by is not null then
        v_query := v_query || ' and p.updated_by ilike ''' || g_updated_by || '''';
    end if;

    if g_active is not null then
        v_query := v_query || ' and p.active = ' || g_active;
    end if;

    return query execute 'select p.product_id, p.product_name, p.price, p.created_date from product p where 1=1' || v_query;
end;
$$;

alter function get_product(integer, varchar, numeric, varchar, varchar, boolean) owner to postgres;

