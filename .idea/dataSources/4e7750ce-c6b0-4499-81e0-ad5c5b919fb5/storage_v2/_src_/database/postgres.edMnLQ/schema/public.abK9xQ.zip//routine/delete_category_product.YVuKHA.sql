create function delete_category_product(p_category_id integer, p_product_id integer) returns void
    language plpgsql
as
$$
begin
    update category_product set active = false
    where category_id = p_category_id and product_id = p_product_id;
end;
$$;

alter function delete_category_product(integer, integer) owner to postgres;

