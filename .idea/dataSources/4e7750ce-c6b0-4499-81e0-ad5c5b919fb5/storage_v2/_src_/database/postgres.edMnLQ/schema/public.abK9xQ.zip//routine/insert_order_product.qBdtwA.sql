create function insert_order_product(i_order_id integer, i_cart_id integer, i_created_by character varying)
    returns TABLE(order_product_id integer, order_id integer, product_id integer, created_date timestamp without time zone)
    language plpgsql
as
$$
begin
    return query
        insert into order_product (order_id, cart_id, created_by)
            values (i_order_id, i_cart_id, i_created_by)
            returning order_product.order_product_id, order_product.order_id, order_product.cart_id, order_product.created_date;
end;
$$;

alter function insert_order_product(integer, integer, varchar) owner to postgres;

