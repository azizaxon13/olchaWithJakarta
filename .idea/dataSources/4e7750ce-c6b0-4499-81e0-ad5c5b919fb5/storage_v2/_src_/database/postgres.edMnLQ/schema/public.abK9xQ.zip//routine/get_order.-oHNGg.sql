create function get_order(g_order_id integer DEFAULT 0, g_user_id integer DEFAULT 0, g_promo_code_id integer DEFAULT 0, g_total_price numeric DEFAULT NULL::numeric, g_status character varying DEFAULT NULL::character varying, g_created_date timestamp without time zone DEFAULT NULL::timestamp without time zone, g_updated_date timestamp without time zone DEFAULT NULL::timestamp without time zone, g_created_by character varying DEFAULT NULL::character varying, g_updated_by character varying DEFAULT NULL::character varying, g_active boolean DEFAULT NULL::boolean)
    returns TABLE(order_id integer, user_id integer, promo_code_id integer, total_price numeric, status character varying, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying)
    language plpgsql
as
$$
declare
    v_query text := 'select o.order_id, o.user_id, o.promo_code_id, o.total_price, o.status, o.created_date, o.updated_date, o.created_by, o.updated_by from orders o where 1=1';
begin
    if g_order_id != 0 then
        v_query := v_query || ' and o.order_id = ' || g_order_id;
    end if;

    if g_user_id != 0 then
        v_query := v_query ||'and o.user_id = ' || g_user_id;
    end if;

    if g_promo_code_id != 0 then
        v_query := v_query ||'and o.promo_code_id = ' || g_promo_code_id;
    end if;

    if g_total_price is not null then
        v_query := v_query ||'and o.total_price = ' || g_total_price;
        end if;

    if g_status is not null then
        v_query := v_query ||'and o.status ilike ''' || g_status || '''';
    end if;

    if g_created_date is not null then
        v_query := v_query ||'and o.created_date = ''' || g_created_date || '''';
        end if;

    if g_updated_date is not null then
        v_query := v_query ||'and o.updated_date = ''' || g_updated_date || '''';
        end if;

    if g_created_by is not null then
        v_query := v_query ||'and o.created_by ilike ''' || g_created_by || '''';
        end if;

    if g_updated_by is not null then
        v_query := v_query ||'and o.updated_by ilike ''' || g_updated_by || '''';
        end if;

    if g_active is not null then
        v_query := v_query ||'and o.active = ' || g_active;
    end if;

    return query execute v_query;
end;
$$;

alter function get_order(integer, integer, integer, numeric, varchar, timestamp, timestamp, varchar, varchar, boolean) owner to postgres;

