create function get_order_product(g_order_product_id integer DEFAULT 0, g_order_id integer DEFAULT 0, g_cart_id integer DEFAULT 0, g_created_date timestamp without time zone DEFAULT NULL::timestamp without time zone, g_updated_date timestamp without time zone DEFAULT NULL::timestamp without time zone, g_created_by character varying DEFAULT NULL::character varying, g_updated_by character varying DEFAULT NULL::character varying, g_active boolean DEFAULT NULL::boolean)
    returns TABLE(order_product_id integer, order_id integer, cart_id integer, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying)
    language plpgsql
as
$$
declare
    v_query text := 'select op.order_product_id, op.order_id, op.cart_id, op.created_date, op.updated_date, op.created_by, op.updated_by from order_product op where 1=1';
begin
    if g_order_product_id != 0 then
        v_query := v_query || ' and op.order_product_id = ' || g_order_product_id;
    end if;

    if g_order_id != 0 then
        v_query := v_query ||'and op.order_id = ' || g_order_id;
    end if;

    if g_cart_id != 0 then
        v_query := v_query ||'and op.cart_id = ' || g_cart_id;
    end if;

    if g_created_date is not null then
        v_query := v_query ||'and op.created_date = ''' || g_created_date || '''';
        end if;

    if g_updated_date is not null then
        v_query := v_query ||'and op.updated_date = ''' || g_updated_date || '''';
        end if;

      if g_created_by is not null then
        v_query := v_query ||'and op.created_by ilike ''' || g_created_by || '''';
    end if;

    if g_updated_by is not null then
        v_query := v_query ||'and op.updated_by ilike ''' || g_updated_by || '''';
    end if;

    if g_active is not null then
        v_query := v_query ||'and op.active = ' || g_active;
    end if;

    return query execute v_query;
end;
$$;

alter function get_order_product(integer, integer, integer, timestamp, timestamp, varchar, varchar, boolean) owner to postgres;

