create function get_all_users()
    returns TABLE(user_id integer, name character varying, phone_number character varying, email character varying, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying, active boolean)
    language plpgsql
as
$$
begin
    return query
        select users.user_id, users.name, users.phone_number, users.email, users.created_date, users.updated_date, users.created_by, users.updated_by, users.active
        from users where users.active = true;
end;
$$;

alter function get_all_users() owner to postgres;

