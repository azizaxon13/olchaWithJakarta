create function update_cart(u_cart_id integer, u_user_id integer DEFAULT NULL::integer, u_product_id integer DEFAULT NULL::integer, u_quantity integer DEFAULT NULL::integer, u_updated_by character varying DEFAULT NULL::character varying)
    returns TABLE(cart_id integer, user_id integer, product_id integer, quantity integer, updated_date timestamp without time zone)
    language plpgsql
as
$$
declare
    v_variable text := '';
begin
    if u_user_id is not null then
        v_variable := v_variable || 'user_id = ' || u_user_id || ', ';
    end if;

    if u_product_id is not null then
        v_variable := v_variable || 'product_id = ' || u_product_id|| ', ';
    end if;

    if u_quantity is not null then
            v_variable := v_variable || 'quantity = ' || u_quantity || ', ';
    end if;

    if u_updated_by is not null then
        v_variable := v_variable || 'updated_by = ''' || u_updated_by || ''', ';
    end if;

    if length(v_variable) > 0 then
        execute 'update cart set ' || v_variable || 'updated_date = current_timestamp where cart_id = ' || u_cart_id;
    end if;

    return query
        select c.cart_id, c.user_id, c.product_id, c.quantity, c.updated_date
        from cart c
        where c.cart_id = u_cart_id;
end
$$;

alter function update_cart(integer, integer, integer, integer, varchar) owner to postgres;

