create function get_promo_code(g_promo_code_id integer DEFAULT 0, g_value character varying DEFAULT NULL::character varying, g_type character varying DEFAULT NULL::character varying, g_created_by character varying DEFAULT NULL::character varying, g_updated_by character varying DEFAULT NULL::character varying, g_active boolean DEFAULT NULL::boolean)
    returns TABLE(promo_code_id integer, value character varying, type character varying, created_date timestamp without time zone)
    language plpgsql
as
$$
declare
    v_query text := 'select p.promo_code_id, p.value, p.type, p.created_date from promo_code p where 1=1';
begin
    if g_promo_code_id != 0 then
        v_query := v_query || ' and p.promo_code_id = ' || g_promo_code_id;
    end if;

    if g_value is not null then
        v_query := v_query || ' and p.value ilike ''' || g_value || '''';
    end if;

    if g_type is not null then
        v_query := v_query || ' and p.type = ''' || g_type || '''';
    end if;

    if g_created_by is not null then
        v_query := v_query || ' and p.created_by ilike ''' || g_created_by || '''';
    end if;

    if g_updated_by is not null then
        v_query := v_query || ' and p.updated_by ilike ''' || g_updated_by || '''';
    end if;

    if g_active is not null then
        v_query := v_query || ' and p.active = ' || g_active;
    end if;

    return query execute v_query;
end;
$$;

alter function get_promo_code(integer, varchar, varchar, varchar, varchar, boolean) owner to postgres;

