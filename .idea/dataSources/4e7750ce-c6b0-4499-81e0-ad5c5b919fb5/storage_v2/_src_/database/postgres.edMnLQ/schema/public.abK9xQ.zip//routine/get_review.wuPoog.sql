create function get_review(g_review_id integer DEFAULT 0, g_product_id integer DEFAULT NULL::integer, g_user_id integer DEFAULT NULL::integer, g_rating integer DEFAULT NULL::integer, g_created_by character varying DEFAULT NULL::character varying, g_updated_by character varying DEFAULT NULL::character varying, g_active boolean DEFAULT NULL::boolean)
    returns TABLE(review_id integer, product_id integer, user_id integer, rating integer, created_date timestamp without time zone)
    language plpgsql
as
$$
declare
    v_query text := 'select r.review_id, r.product_id, r.user_id, r.rating, r.created_date from review r where 1=1';
begin
    if g_review_id != 0 then
        v_query := v_query || ' and r.review_id = ' || g_review_id;
    end if;

    if g_product_id is not null then
        v_query := v_query || ' and r.product_id = ' || g_product_id;
    end if;

    if g_user_id is not null then
        v_query := v_query || ' and r.user_id = ' || g_user_id;
    end if;

    if g_rating is not null then
        v_query := v_query || ' and r.rating = ' || g_rating;
    end if;

    if g_created_by is not null then
        v_query := v_query || ' and r.created_by ilike ''' || g_created_by || '''';
    end if;

    if g_updated_by is not null then
        v_query := v_query || ' and r.updated_by ilike ''' || g_updated_by || '''';
    end if;

    if g_active is not null then
        v_query := v_query || ' and r.active = ' || g_active;
    end if;

    return query execute v_query;
end;
$$;

alter function get_review(integer, integer, integer, integer, varchar, varchar, boolean) owner to postgres;

