create function get_all_orders_by_status_priority()
    returns TABLE(order_id integer, user_id integer, product_id integer, product_name text, description text, price numeric, quantity integer, status text)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            o.order_id,            -- Assuming 'order_id' is the correct column in 'orders'
            o.user_id,             -- Assuming 'user_id' is present in 'orders'
            p.product_id,
            p.product_name,
            p.description,
            p.price,
            op.quantity,
            op.status
        FROM
            orders o
                JOIN
            order_product op ON o.order_id = op.order_id   -- Using 'order_id' instead of 'id'
                JOIN
            product p ON op.product_id = p.product_id
        ORDER BY
            CASE
                WHEN op.status = 'MISSED' THEN 1
                WHEN op.status = 'PREVIOUSLY_ORDERED' THEN 2
                WHEN op.status = 'SUCCESS' THEN 3
                ELSE 4
                END;
END;
$$;

alter function get_all_orders_by_status_priority() owner to postgres;

