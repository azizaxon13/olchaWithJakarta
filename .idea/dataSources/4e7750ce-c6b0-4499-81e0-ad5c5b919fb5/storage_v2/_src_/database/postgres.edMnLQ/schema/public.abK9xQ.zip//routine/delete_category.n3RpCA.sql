create function delete_category(p_category_id integer)
    returns TABLE(category_id integer, category_name text, parent_id integer, created_date timestamp without time zone)
    language plpgsql
as
$$
begin
    return query
        update category set active = false
            where category_id = p_category_id and last_category = true
            returning category_id, category_name, parent_id, created_date;

    perform delete_product(p_category_id);
end;
$$;

alter function delete_category(integer) owner to postgres;

