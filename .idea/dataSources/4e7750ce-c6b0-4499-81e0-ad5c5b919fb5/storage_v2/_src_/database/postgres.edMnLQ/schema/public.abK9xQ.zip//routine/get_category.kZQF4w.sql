create function get_category(g_category_id integer DEFAULT 0, g_category_name character varying DEFAULT NULL::character varying, g_parent_id integer DEFAULT NULL::integer, g_last_category boolean DEFAULT NULL::boolean, g_created_by character varying DEFAULT NULL::character varying, g_updated_by character varying DEFAULT NULL::character varying, g_active boolean DEFAULT NULL::boolean)
    returns TABLE(category_id integer, category_name character varying, parent_id integer, last_category boolean, created_date timestamp without time zone)
    language plpgsql
as
$$
declare
    v_query text := 'select c.category_id, c.category_name, c.parent_id, c.last_category, c.created_date from category c where 1=1';  -- base query
begin
    if g_category_id != 0 then
        v_query := v_query || ' and c.category_id = ' || g_category_id;
    end if;

    if g_category_name is not null then
        v_query := v_query || ' and c.category_name ilike ''' || g_category_name || '''';
    end if;

    if g_parent_id is not null then
        v_query := v_query || ' and c.parent_id = ' || g_parent_id;
    end if;

    if g_last_category is not null then
        v_query := v_query || ' and c.last_category = ' || g_last_category;
    end if;

    if g_created_by is not null then
        v_query := v_query || ' and c.created_by ilike ''' || g_created_by || '''';
    end if;

    if g_updated_by is not null then
        v_query := v_query || ' and c.updated_by ilike ''' || g_updated_by || '''';
    end if;

    if g_active is not null then
        v_query := v_query || ' and c.active = ' || g_active;
    end if;

    return query execute v_query;
end;
$$;

alter function get_category(integer, varchar, integer, boolean, varchar, varchar, boolean) owner to postgres;

