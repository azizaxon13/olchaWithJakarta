create function print_numbers() returns void
    language plpgsql
as
$$
DECLARE
    i INTEGER;
BEGIN
    FOR i IN 1..100 LOOP
            RAISE NOTICE 'Number: %', i;
        END LOOP;
END;
$$;

alter function print_numbers() owner to postgres;

