create function update_order(u_order_id integer, u_user_id integer DEFAULT NULL::integer, u_promo_code_id integer DEFAULT NULL::integer, u_total_price numeric DEFAULT NULL::numeric, u_status character varying DEFAULT NULL::character varying, u_updated_by character varying DEFAULT NULL::character varying)
    returns TABLE(order_id integer, user_id integer, promo_code_id integer, total_price numeric, status character varying, updated_date timestamp without time zone)
    language plpgsql
as
$$
declare
    v_variable text := '';
begin
    if u_user_id != 0 then
        v_variable := v_variable || 'user_id = ' || u_user_id || ', ';
    end if;

    if u_promo_code_id != 0 then
        v_variable := v_variable || 'promo_code_id = ' || u_promo_code_id || ', ';
    end if;

    if u_total_price is not null then
        v_variable := v_variable || 'total_price = ' || u_total_price || ', ';
    end if;

    if u_status is not null then
        -- Update the status case-insensitively by converting to lowercase
        v_variable := v_variable || 'status = LOWER(''' || u_status || '''), ';
    end if;

    if u_updated_by is not null then
        -- Update the updated_by case-insensitively by converting to lowercase
        v_variable := v_variable || 'updated_by = LOWER(''' || u_updated_by || '''), ';
    end if;

    -- Remove the last comma and space
    if length(v_variable) > 0 then
        v_variable := left(v_variable, length(v_variable) - 2);  -- remove last comma
        execute 'update orders set ' || v_variable || ', updated_date = current_timestamp where order_id = ' || u_order_id;
    end if;

    return query
        select o.order_id, o.user_id, o.promo_code_id, o.total_price, o.status, o.updated_date
        from orders o
        where o.order_id = u_order_id;
end;
$$;

alter function update_order(integer, integer, integer, numeric, varchar, varchar) owner to postgres;

