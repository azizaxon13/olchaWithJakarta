create function get_user_cards(i_owner_id integer)
    returns TABLE(owner_id integer, card_id integer, card_name character varying, balance integer, expiry_date integer, active boolean)
    language plpgsql
as
$$
begin
    return query
        select c.owner_id, c.card_id, c.card_name, c.balance, c.expiry_date, c.active from cards c where c.owner_id = i_owner_id;
end;
$$;

alter function get_user_cards(integer) owner to postgres;

