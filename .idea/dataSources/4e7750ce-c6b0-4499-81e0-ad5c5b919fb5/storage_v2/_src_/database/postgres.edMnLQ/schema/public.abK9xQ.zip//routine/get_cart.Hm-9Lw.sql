create function get_cart(g_cart_id integer DEFAULT NULL::integer, g_user_id integer DEFAULT NULL::integer, g_product_id integer DEFAULT NULL::integer, g_quantity integer DEFAULT NULL::integer, g_created_date timestamp without time zone DEFAULT NULL::timestamp without time zone, g_updated_date timestamp without time zone DEFAULT NULL::timestamp without time zone, g_created_by character varying DEFAULT NULL::character varying, g_updated_by character varying DEFAULT NULL::character varying, g_active boolean DEFAULT NULL::boolean)
    returns TABLE(cart_id integer, user_id integer, product_id integer, quantity integer, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying, active boolean)
    language plpgsql
as
$$
declare
    v_query text := 'select c.cart_id, c.user_id, c.product_id, c.quantity, c.created_date, c.updated_date, c.created_by,c.updated_by, c.active from cart c where 1=1';
begin
    if g_cart_id != 0 then
        v_query := v_query || ' and c.cart_id = ' || g_cart_id;
    end if;

    if g_user_id is not null then
        v_query := v_query || ' and c.user_id = ' || g_user_id;
    end if;

    if g_product_id is not null then
        v_query := v_query || ' and c.product_id = ' || g_product_id;
    end if;

    if g_quantity is not null then
        v_query := v_query || ' and c.quantity = ' || g_quantity;
    end if;

    if g_created_date is not null then
        v_query := v_query || ' and c.created_date = ''' || g_created_date || '''';
    end if;

    if g_updated_date is not null then
        v_query := v_query || ' and c.updated_date = ''' || g_updated_date || '''';
    end if;

    if g_created_by is not null then
        v_query := v_query || ' and c.created_by ilike ''' || g_created_by || '''';
    end if;

    if g_updated_by is not null then
        v_query := v_query || ' and c.updated_by ilike ''' || g_updated_by || '''';
    end if;

    if g_active is not null then
        v_query := v_query || ' and c.active = ' || g_active;
    end if;

    return query execute v_query;
end;
$$;

alter function get_cart(integer, integer, integer, integer, timestamp, timestamp, varchar, varchar, boolean) owner to postgres;

