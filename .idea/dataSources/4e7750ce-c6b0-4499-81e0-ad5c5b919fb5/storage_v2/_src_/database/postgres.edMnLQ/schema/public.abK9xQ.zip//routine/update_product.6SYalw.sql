create function update_product(u_product_id integer, u_product_name character varying DEFAULT NULL::character varying, u_price numeric DEFAULT NULL::numeric, u_description text DEFAULT NULL::text, u_images json DEFAULT NULL::json, u_params json DEFAULT NULL::json, u_colors json DEFAULT NULL::json, u_discount_percent numeric DEFAULT NULL::numeric, u_from_delivery integer DEFAULT NULL::integer, u_to_delivery integer DEFAULT NULL::integer, u_updated_by character varying DEFAULT NULL::character varying)
    returns TABLE(product_id integer, product_name character varying, price numeric, updated_date timestamp without time zone)
    language plpgsql
as
$$
declare
    v_variable text := '';
begin
    if u_product_name is not null then
        v_variable := v_variable || 'product_name = ''' || u_product_name || ''', ';
    end if;

    if u_price is not null then
        v_variable := v_variable || 'price = ' || u_price || ', ';
    end if;

    if u_description is not null then
        v_variable := v_variable || 'description = ''' || u_description || ''', ';
    end if;

    if u_images is not null then
        v_variable := v_variable || 'images = ''' || u_images || ''', ';
    end if;

    if u_params is not null then
        v_variable := v_variable || 'params = ''' || u_params || ''', ';
    end if;

    if u_colors is not null then
        v_variable := v_variable || 'colors = ''' || u_colors || ''', ';
    end if;

    if u_discount_percent is not null then
        v_variable := v_variable || 'discount_percent = ' || u_discount_percent || ', ';
    end if;

    if u_from_delivery is not null then
        v_variable := v_variable || 'from_delivery = ' || u_from_delivery || ', ';
    end if;

    if u_to_delivery is not null then
        v_variable := v_variable || 'to_delivery = ' || u_to_delivery || ', ';
    end if;

    if u_updated_by is not null then
        v_variable := v_variable || 'updated_by = ''' || u_updated_by || ''', ';
    end if;

    if length(v_variable) > 0 then
        v_variable := rtrim(v_variable, ', ');
        execute 'update product set ' || v_variable || ', updated_date = current_timestamp where product_id = ' || u_product_id;
    end if;

    return query
        select p.product_id, p.product_name, p.price, p.updated_date
        from product p
        where p.product_id = u_product_id;
end;
$$;

alter function update_product(integer, varchar, numeric, text, json, json, json, numeric, integer, integer, varchar) owner to postgres;

