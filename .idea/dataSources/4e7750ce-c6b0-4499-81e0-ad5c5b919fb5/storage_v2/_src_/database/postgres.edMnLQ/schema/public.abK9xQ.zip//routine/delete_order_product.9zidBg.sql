create function delete_order_product(p_order_product_id integer)
    returns TABLE(order_product_id integer, order_id integer, cart_id integer, active boolean)
    language plpgsql
as
$$
begin
    return query
        update order_product op
            set active = false
            where op.order_product_id = p_order_product_id and op.active = true
            returning op.order_product_id, op.cart_id, op.order_id, op.active;
end;
$$;

alter function delete_order_product(integer) owner to postgres;

