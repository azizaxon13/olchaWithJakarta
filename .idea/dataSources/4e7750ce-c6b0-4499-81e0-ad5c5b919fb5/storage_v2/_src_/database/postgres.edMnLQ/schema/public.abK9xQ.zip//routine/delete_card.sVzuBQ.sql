create function delete_card(i_card_id integer)
    returns TABLE(owner_id integer, card_id integer, card_name character varying, card_number character varying, card_balance integer, card_expiry_date integer, active boolean)
    language plpgsql
as
$$
begin

end;
$$;

alter function delete_card(integer) owner to postgres;

