create function get_orders_json() returns jsonb
    language plpgsql
as
$$
DECLARE
    v_orders_json jsonb;
BEGIN
    -- Aggregate the orders table into JSON format
    SELECT jsonb_agg(order_row)
    INTO v_orders_json
    FROM (
             SELECT * FROM orders
         ) AS order_row;

    -- Return the JSON result
    RETURN v_orders_json;
END;
$$;

alter function get_orders_json() owner to postgres;

