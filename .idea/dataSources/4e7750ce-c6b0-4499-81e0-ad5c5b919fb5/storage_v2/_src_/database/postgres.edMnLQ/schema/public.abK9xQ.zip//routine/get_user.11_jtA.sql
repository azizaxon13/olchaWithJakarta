create function get_user(g_user_id integer DEFAULT 0, g_name character varying DEFAULT NULL::character varying, g_phone_number character varying DEFAULT NULL::character varying, g_password character varying DEFAULT NULL::character varying, g_email character varying DEFAULT NULL::character varying, g_created_date timestamp without time zone DEFAULT NULL::timestamp without time zone, g_updated_date timestamp without time zone DEFAULT NULL::timestamp without time zone, g_created_by character varying DEFAULT NULL::character varying, g_updated_by character varying DEFAULT NULL::character varying, g_active boolean DEFAULT NULL::boolean)
    returns TABLE(user_id integer, name character varying, phone_number character varying, email character varying, created_date timestamp without time zone)
    language plpgsql
as
$$
declare
    v_query text := 'select u.user_id, u.name, u.phone_number, u.email, u.created_date from users u where 1=1';  -- base query
begin
    if g_user_id != 0 then
        v_query := v_query || ' and u.user_id = ' || g_user_id;
    end if;

    if g_name is not null then
        v_query := v_query || ' and u.name ilike ''' || g_name || '''';
    end if;

    if g_phone_number is not null then
        v_query := v_query || ' and u.phone_number = ''' || g_phone_number || '''';
    end if;

    if g_password is not null then
        v_query := v_query || ' and u.password ilike ''' || g_password || '''';
    end if;

    if g_email is not null then
        v_query := v_query || ' and u.email ilike ''' || g_email || '''';
    end if;

    if g_created_date is not null then
        v_query := v_query || ' and u.created_date = ''' || g_created_date || '''';
    end if;

    if g_updated_date is not null then
        v_query := v_query || ' and u.updated_date = ''' || g_updated_date || '''';
    end if;

    if g_created_by is not null then
        v_query := v_query || ' and u.created_by ilike ''' || g_created_by || '''';
    end if;

    if g_updated_by is not null then
        v_query := v_query || ' and u.updated_by ilike ''' || g_updated_by || '''';
    end if;

    if g_active is not null then
        v_query := v_query || ' and u.active = ' || g_active;
    end if;

    return query execute v_query;
end;
$$;

alter function get_user(integer, varchar, varchar, varchar, varchar, timestamp, timestamp, varchar, varchar, boolean) owner to postgres;

