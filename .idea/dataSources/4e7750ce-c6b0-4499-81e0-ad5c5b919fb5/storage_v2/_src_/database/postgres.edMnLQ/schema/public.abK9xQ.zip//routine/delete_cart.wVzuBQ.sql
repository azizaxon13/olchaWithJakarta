create function delete_cart(p_cart_id integer)
    returns TABLE(cart_id integer, user_id integer, product_id integer, quantity integer, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying, active boolean)
    language plpgsql
as
$$
begin
    return query
        update cart c
            set active = false
            where c.cart_id = p_cart_id and c.active = true
            returning c.cart_id, c.user_id, c.product_id, c.quantity, c.created_date, c.updated_date, c.created_by, c.updated_by, c.active;
end;
$$;

alter function delete_cart(integer) owner to postgres;

