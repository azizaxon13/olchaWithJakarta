create function insert_promo_code(i_value character varying, i_discount_percent numeric DEFAULT NULL::numeric, i_type character varying DEFAULT NULL::character varying, i_start_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP, i_days integer DEFAULT 0, i_fixed_amount numeric DEFAULT NULL::numeric, i_min_amount numeric DEFAULT NULL::numeric, i_created_by character varying DEFAULT NULL::character varying)
    returns TABLE(promo_code_id integer, out_value character varying, out_type character varying, out_created_date timestamp without time zone)
    language plpgsql
as
$$
begin
    return query
        insert into promo_code (
                                value, discount_percent, type, start_date, days, fixed_amount, min_amount, created_by
            )
            values (
                       i_value, i_discount_percent, i_type, i_start_date, i_days, i_fixed_amount, i_min_amount, i_created_by
                   )
            returning promo_code.promo_code_id, promo_code.value, promo_code.type, promo_code.created_date;
end;
$$;

alter function insert_promo_code(varchar, numeric, varchar, timestamp, integer, numeric, numeric, varchar) owner to postgres;

