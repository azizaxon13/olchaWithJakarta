create function get_orders_by_status_priority(i_order_id integer)
    returns TABLE(order_id integer, product_id integer, product_name text, description text, price numeric, quantity integer, status text)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT
            op.order_id,
            p.product_id,
            p.product_name,
            p.description,
            p.price,
            op.quantity,
            op.status
        FROM
            order_product op
                JOIN
            product p ON op.product_id = p.product_id
        WHERE
            op.order_id = i_order_id
        ORDER BY
            CASE
                WHEN op.status = 'MISSED' THEN 1
                WHEN op.status = 'PREVIOUSLY_ORDERED' THEN 2
                WHEN op.status = 'SUCCESS' THEN 3
                ELSE 4
                END;
END;
$$;

alter function get_orders_by_status_priority(integer) owner to postgres;

