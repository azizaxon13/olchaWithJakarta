create function get_category_product(g_category_product_id integer DEFAULT 0, g_category_id integer DEFAULT 0, g_product_id integer DEFAULT 0, g_created_date timestamp without time zone DEFAULT NULL::timestamp without time zone, g_updated_date timestamp without time zone DEFAULT NULL::timestamp without time zone, g_created_by character varying DEFAULT NULL::character varying, g_updated_by character varying DEFAULT NULL::character varying, g_active boolean DEFAULT NULL::boolean)
    returns TABLE(category_product_id integer, category_id integer, product_id integer, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying)
    language plpgsql
as
$$
declare
    v_query text := 'select cp.category_product_id, cp.category_id, cp.product_id, cp.created_date, cp.updated_date, cp.created_by, cp.updated_by from orders cp where 1=1';
begin
    if g_category_product_id != 0 then
        v_query := v_query || ' and cp.category_product_id = ' || g_category_product_id;
    end if;

    if g_category_id != 0 then
        v_query := v_query ||'and cp.category_id = ' || g_category_id;
    end if;

    if g_product_id != 0 then
        v_query := v_query ||'and cp.product_id = ' || g_product_id;
    end if;

    if g_created_date is not null then
        v_query := v_query ||'and cp.created_date = ''' || g_created_date || '''';
        end if;

    if g_updated_date is not null then
        v_query := v_query ||'and cp.updated_date = ''' || g_updated_date || '''';
    end if;

    if g_created_by is not null then
        v_query := v_query ||'and cp.created_by ilike ''' || g_created_by || '''';
    end if;

    if g_updated_by is not null then
        v_query := v_query ||'and cp.updated_by ilike ''' || g_updated_by || '''';
    end if;

    if g_active is not null then
        v_query := v_query ||'and cp.active = ' || g_active;
    end if;

    return query execute v_query;
end;
$$;

alter function get_category_product(integer, integer, integer, timestamp, timestamp, varchar, varchar, boolean) owner to postgres;

