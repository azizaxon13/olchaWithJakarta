create function deactivate_carts(i_product_id integer, i_user_id integer) returns void
    language plpgsql
as
$$
begin
    update cart
    set active = false
    where user_id = i_user_id
      and product_id = i_product_id
      and active = true;
end;
$$;

alter function deactivate_carts(integer, integer) owner to postgres;

