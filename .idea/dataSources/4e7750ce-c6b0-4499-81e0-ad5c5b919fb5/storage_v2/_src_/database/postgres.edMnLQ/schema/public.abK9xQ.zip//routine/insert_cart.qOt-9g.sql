create function insert_cart(i_user_id integer, i_product_id integer, i_quantity integer, i_created_by character varying)
    returns TABLE(cart_id integer, user_id integer, product_id integer, quantity integer, created_date timestamp without time zone, created_by character varying)
    language plpgsql
as
$$
begin
    return query
        insert into cart( user_id, product_id, quantity, created_by)
            values (i_user_id, i_product_id, i_quantity, i_created_by)
            returning cart.cart_id, cart.user_id, cart.product_id, cart.quantity,cart.created_date,cart.created_by;
end;
$$;

alter function insert_cart(integer, integer, integer, varchar) owner to postgres;

