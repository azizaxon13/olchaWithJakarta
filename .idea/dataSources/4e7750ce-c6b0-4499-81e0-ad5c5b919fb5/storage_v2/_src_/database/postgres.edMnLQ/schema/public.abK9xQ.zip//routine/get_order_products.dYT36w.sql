create function get_order_products(i_order_id integer DEFAULT NULL::integer, i_name character varying DEFAULT NULL::character varying, i_promo_code character varying DEFAULT NULL::character varying, i_product_name character varying DEFAULT NULL::character varying, i_product_price numeric DEFAULT NULL::integer, i_product_quantity integer DEFAULT NULL::integer, i_order_status character varying DEFAULT NULL::character varying, i_order_created character varying DEFAULT NULL::character varying, i_from_created_date character varying DEFAULT NULL::character varying, i_to_created_date character varying DEFAULT NULL::character varying)
    returns TABLE(order_created_date timestamp without time zone, order_id integer, order_status character varying, name character varying, phone_number character varying, email character varying, value character varying, promo_code_discount_percent numeric, type character varying, start_date timestamp without time zone, days integer, fixed_amount numeric, min_amount numeric)
    language plpgsql
as
$$
declare
    v_query text := '';
begin
    if i_order_id <> 0 then
        v_query := v_query || ' and o.order_id = ' || i_order_id;
    end if;

    if i_name is not null then
        v_query := v_query || ' and u.name ilike ''%' || i_name || '%''';
    end if;

    if i_promo_code is not null then
        v_query := v_query || ' and pr.value ilike ''%' || i_promo_code || '%''';
    end if;

    if i_product_name is not null then
        v_query := v_query || ' and p.name ilike ''%' || i_product_name || '%''';
    end if;

    if i_product_price <> 0 then
        v_query := v_query || ' and p.price = ' || i_product_price;
    end if;

    if i_product_quantity <> 0 then
        v_query := v_query || ' and pr.quantity = ' || i_product_quantity;
    end if;

    if i_order_status is not null then
        v_query := v_query || ' and o.status ilike ''%' || i_order_status || '%''';
    end if;

    if i_order_created is not null then
        v_query := v_query || ' and o.created_date = ' || i_order_created;
    end if;

--     if i_ is not null then
--         v_query := v_query || ' and o.active = ' || i_order_created;
--     end if;

    return query execute 'select distinct
            o.created_date,
            o.order_id,
            o.status,
            u.name,
            u.phone_number,
            u.email,
            pr.value,
            pr.discount_percent,
            pr.type,
            pr.start_date,
            pr.days,
            pr.fixed_amount,
            pr.min_amount
        from
            orders o
                join order_product op on o.order_id = op.order_id
                join users u on u.user_id = o.user_id
                join product p on p.product_id = op.product_id
                join promo_code pr on pr.promo_code_id = o.promo_code_id
        where
            1=1' || v_query || ' order by o.created_date desc';
end;
$$;

alter function get_order_products(integer, varchar, varchar, varchar, numeric, integer, varchar, varchar, varchar, varchar) owner to postgres;

