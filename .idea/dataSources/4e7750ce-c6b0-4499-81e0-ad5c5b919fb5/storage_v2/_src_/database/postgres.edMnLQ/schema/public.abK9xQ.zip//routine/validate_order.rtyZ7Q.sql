create function validate_order(i_order_json jsonb) returns text
    language plpgsql
as
$$
DECLARE
    v_order_id int := 0;
    v_product jsonb;
    v_inactive_products jsonb := '[]'::jsonb;
    v_created_products jsonb := '[]'::jsonb;
    v_product_active boolean;
    v_result jsonb;
BEGIN
    -- Check if all products are active
    FOR v_product IN SELECT jsonb_array_elements(i_order_json -> 'products') LOOP
            SELECT active INTO v_product_active
            FROM product
            WHERE product_id = (v_product ->> 'productId')::int;

            IF NOT v_product_active THEN
                v_inactive_products := v_inactive_products || jsonb_build_object(
                        'productId', (v_product ->> 'productId')::int,
                        'productName', (SELECT product_name FROM product WHERE product_id = (v_product ->> 'productId')::int),
                        'reason', 'Product is inactive'
                                                              );
            END IF;
        END LOOP;

    -- If there are inactive products, return the detailed list and abort order creation
    IF jsonb_array_length(v_inactive_products) > 0 THEN
        v_result := jsonb_build_object('status', 'error', 'inactiveProducts', v_inactive_products);
        RETURN jsonb_pretty(v_result);
    END IF;

    -- Create order if all products are active
    INSERT INTO orders(user_id, status, promo_code_id)
    VALUES ((i_order_json ->> 'userId')::int, 'CREATED', (i_order_json ->> 'promoCodeId')::int)
    RETURNING order_id INTO v_order_id;

    -- Loop through the products and create order_product entries
    FOR v_product IN SELECT jsonb_array_elements(i_order_json -> 'products') LOOP
            INSERT INTO order_product(order_id, product_id, quantity)
            VALUES(v_order_id, (v_product ->> 'productId')::int, (v_product ->> 'quantity')::int);

            -- Add successfully created product details to the created products list
            v_created_products := v_created_products || jsonb_build_object(
                    'productId', (v_product ->> 'productId')::int,
                    'productName', (SELECT product_name FROM product WHERE product_id = (v_product ->> 'productId')::int),
                    'quantity', (v_product ->> 'quantity')::int
                                                        );

            -- Deactivate the cart entries
            PERFORM deactivate_carts((v_product ->> 'productId')::int, (i_order_json ->> 'userId')::int);
        END LOOP;

    -- Build the success response
    v_result := jsonb_build_object(
            'status', 'success',
            'orderId', v_order_id,
            'createdProducts', v_created_products
                );

    -- Return the pretty-printed result
    RETURN jsonb_pretty(v_result);
END;
$$;

alter function validate_order(jsonb) owner to postgres;

