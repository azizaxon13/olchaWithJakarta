create function delete_review(p_review_id integer)
    returns TABLE(review_id integer, product_id integer, user_id integer, rating integer, created_date timestamp without time zone, updated_date timestamp without time zone, created_by character varying, updated_by character varying, active boolean)
    language plpgsql
as
$$
begin
    return query
        update review r
            set active = false
            where r.review_id = p_review_id and r.active = true
            returning r.review_id, r.product_id, r.user_id, r.rating, r.created_date, r.updated_date, r.created_by, r.updated_by, r.active;
end;
$$;

alter function delete_review(integer) owner to postgres;

